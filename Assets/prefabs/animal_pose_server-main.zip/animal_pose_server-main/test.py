from animal_pose_estimate import AnimalPoseEstimate

img_path = 'sample_images/dog.jpg'  # replace this with your own image path
ai_engine = AnimalPoseEstimate()
result = ai_engine.fetch_keypoints(img_path, show_img=True, vis_out_dir='image_results',
                                   pred_out_dir='keypoints_results')
print(result)
