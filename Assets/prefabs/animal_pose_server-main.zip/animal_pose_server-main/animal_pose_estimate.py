from mmpose.apis import MMPoseInferencer

from constant import INDEX2KEYPOINTS


class AnimalPoseEstimate:

    def __init__(self):
        # create the inferencer using the model alias
        self.inferencer = MMPoseInferencer('animal')

    def fetch_keypoints(self, img_path, show_img=False, vis_out_dir='', pred_out_dir=''):
        # The MMPoseInferencer API employs a lazy inference approach,
        # creating a prediction generator when given input
        """
        - show=True: Determines whether the image or video should be displayed in a pop-up window.
        - vis_out_dir: Specifies the folder path for saving the visualization images. If not set, the visualization
        images will not be saved.
        - pred_out_dir: Specifies the folder path for saving the predictions. If not set, the predictions will not be
        saved.
        """
        result_generator = self.inferencer(img_path, show=show_img, vis_out_dir=vis_out_dir,
                                           pred_out_dir=pred_out_dir)
        result = next(result_generator)
        # print(result)
        predictions = result['predictions'][0][0]
        keypoints = predictions['keypoints']
        # print(keypoints)
        keypoints_result = {}
        bbox = predictions['bbox'][0]
        # print(bbox)
        for index, label in enumerate(INDEX2KEYPOINTS):
            keypoints_result[label] = keypoints[index]
        # print(keypoints_result)
        return {'keypoints': keypoints_result, 'bbox': bbox}
