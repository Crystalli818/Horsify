import os

from flask import Flask, request, jsonify

from animal_pose_estimate import AnimalPoseEstimate

app = Flask(__name__)
animal_pose_estimate = AnimalPoseEstimate()


@app.route("/")
def home():
    return "<h1>Animal Pose Analyzer</h1>"


@app.route('/fetch_pose', methods=['POST'])
def fetch_pose():
    if request.method == 'POST':
        f = request.files['image']
        filename = f.filename
        f.save(filename)
        result = animal_pose_estimate.fetch_keypoints(filename)
        print(result)
        os.remove(filename)
        return jsonify(result)


app.run(host='0.0.0.0')
