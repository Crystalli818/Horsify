# Animal Pose estimate
## Python Review 1-2 weeks
- Container
  - List
    - https://www.w3schools.com/python/python_lists.asp
    - https://www.w3schools.com/python/python_lists_access.asp
    - https://www.w3schools.com/python/python_lists_add.asp
  - Set
    - https://www.w3schools.com/python/python_sets.asp
    - https://www.w3schools.com/python/python_sets_access.asp
    - https://www.w3schools.com/python/python_sets_add.asp
  - Dictionary
    - https://www.w3schools.com/python/python_dictionaries.asp
    - https://www.w3schools.com/python/python_dictionaries_access.asp
    - https://www.w3schools.com/python/python_dictionaries_access.asp
- Functions
  - https://www.w3schools.com/python/python_functions.asp

## AI Engine
1. Install PyTorch following official instructions https://pytorch.org/get-started/locally/ eg. 

``
pip3 install torch torchvision
``

2. Install MMEngine and MMCV using MIM.

``
pip install -U openmim
mim install mmengine
mim install "mmcv>=2.0.0"
``

3. Install MMPose as a Python package

``
mim install "mmpose>=1.0.0"
``

Note: If you encounter a troubleshooting pycocotools installation
  - https://stackoverflow.com/questions/67940561/troubleshooting-pycocotools-installation
  
4. Example code

```
from mmpose.apis import MMPoseInferencer

img_path = 'horse.jpg'  # replace this with your own image path

# create the inferencer using the model alias
inferencer = MMPoseInferencer('animal')


# The MMPoseInferencer API employs a lazy inference approach,
# creating a prediction generator when given input
'''
- show=True: Determines whether the image or video should be displayed in a pop-up window.
- vis_out_dir: Specifies the folder path for saving the visualization images. If not set, the visualization 
images will not be saved.
- pred_out_dir: Specifies the folder path for saving the predictions. If not set, the predictions will not be saved.
'''
result_generator = inferencer(img_path, show=True, vis_out_dir='vis_results', pred_out_dir='keypoints_results')
result = next(result_generator)
print(result)

```
![img.png](README_images/img.png)

## Learn about Flask
To learn and try the Flask library, it will be better to use repl.it or python IDE, since it's more easy to use

- Install Flask using pip

  ```
  pip install Flask

- Flask example 
    ```
      from flask import Flask
      app = Flask(__name__)
      @app.route('/hello/', methods=['GET', 'POST'])
      def welcome():
          return "Hello World!"
      if __name__ == '__main__':
          app.run(host='0.0.0.0')

- Launch any web browser and go to http://localhost:5000/hello/ to see the app in action.

Now, let’s understand the working of the code line-by-line:

  - **from flask import Flask** → Import the Flask class

  - **app = Flask(__name__)** → Create an instance of the class

  - **@app.route('/hello/', methods=['GET', 'POST'])** → We use the route() decorator to tell Flask what URL should trigger the function.
methods specify which HTTP methods are allowed. The default is ['GET']

  - **if __name__ == '__main__'** → __name__ is a special variable in Python which takes the value of the script name. This line ensures that our Flask app runs only when it is executed in the main file and not when it is imported in some other file

  - **app.run(host='0.0.0.0')** → Run the Flask application

    - host specifies the server on which we want our flask application to run. The default value for host is localhost or 127.0.0.1

    - 0.0.0.0 means “all IPv4 addresses on the local machine”. This ensures that the server will be reachable from all addresses.  

- Variable Rules
  - You can add variable sections to a URL by using <variable_name>. The function receives the variable as a keyword argument.    
  - Example:
      ```
        @app.route('/<string:name>/')
        def hello(name):
            return "Hello " + name   
    - Open the browser and go to http://localhost:5000/Jimit , you will see the output as Hello Jimit

- Return JSON Serializable Output

  - The return value from a function in a Flask app should be JSON serializable. You can use jsonify to make your output JSON serializable. This function wraps json.dumps() to turn the JSON output into a Response object with application/json mime-type.
  - Example
    - You can also use jsonify to automatically serialize lists and tuples to JSON Response.
      ```
        from flask import jsonify
        @app.route('/numbers/')
        def print_list():
            return jsonify(list(range(5)))

    - This will produce output as:
      ```
        [
          0, 
          1, 
          2, 
          3, 
          4
        ]
        
# References
- Troubleshooting pycocotools installation
  - https://stackoverflow.com/questions/67940561/troubleshooting-pycocotools-installation
- https://mmpose.readthedocs.io/en/latest/user_guides/inference.html
- https://mmpose.readthedocs.io/en/latest/installation.html
- https://pytorch.org/get-started/locally/
- https://github.com/AlexTheBad/AP-10K/
