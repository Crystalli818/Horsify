KEYPOINTS2INDEX = {'Left Eye': 0, 'Right Eye': 1, 'Nose': 2, 'Neck': 3, 'Root of Tail': 4, 'Left Shoulder': 5,
                   'Left Elbow': 6, 'Left Front Paw': 7, 'Right Shoulder': 8, 'Right Elbow': 9, 'Right Front Paw': 10,
                   'Left Hip': 11, 'Left Knee': 12, 'Left Back Paw': 13, 'Right Hip': 14, 'Right Knee': 15,
                   'Right Back Paw': 16}

INDEX2KEYPOINTS = ['Left Eye', 'Right Eye', 'Nose', 'Neck', 'Root of Tail', 'Left Shoulder',
                   'Left Elbow', 'Left Front Paw', 'Right Shoulder', 'Right Elbow', 'Right Front Paw',
                   'Left Hip', 'Left Knee', 'Left Back Paw', 'Right Hip', 'Right Knee',
                   'Right Back Paw']
